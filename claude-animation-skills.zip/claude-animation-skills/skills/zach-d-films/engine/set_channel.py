#!/usr/bin/env python3
"""Set the channel shown on the subscribe end card.
    python3 set_channel.py <project folder> <human-pattern | professor-kambing>
Copies the channel's avatar into the project as channel.png and writes the CHANNEL line in src/shots.js."""
import json, re, shutil, sys, pathlib
here = pathlib.Path(__file__).resolve().parent
kit = next(p / 'kit' / 'channels' for p in [here, *here.parents] if (p / 'kit' / 'channels' / 'channels.json').exists())
chans = json.load(open(kit / 'channels.json'))
proj, cid = pathlib.Path(sys.argv[1]), sys.argv[2]
if cid not in chans: sys.exit(f"unknown channel '{cid}'. choose: {', '.join(chans)}")
c = chans[cid]
shutil.copy(kit / c['avatar'], proj / 'channel.png')
f = proj / 'src' / 'shots.js'; s = f.read_text()
line = f"export const CHANNEL = {{ name: {json.dumps(c['name'])}, handle: {json.dumps(c['handle'])}, avatar: './channel.png' }};"
s = re.sub(r"export const CHANNEL = .*;", line, s) if 'export const CHANNEL' in s else s.replace("export const SUBSCRIBE_AT", line + "\nexport const SUBSCRIBE_AT")
f.write_text(s); print('channel set:', c['name'], c['handle'])
