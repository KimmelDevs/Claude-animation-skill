#!/usr/bin/env bash
# Render a long project in parallel chunks, then join them: render_parallel.sh silent.mp4 [workers] [fps]
# Each chunk is its own headless Chrome, so a 5 minute video takes minutes instead of an hour.
# Run from the project folder. WORKERS defaults to 4; use fewer on a laptop without a strong GPU.
set -euo pipefail
OUT="${1:?usage: render_parallel.sh out.mp4 [workers] [fps]}"; WORKERS="${2:-4}"; FPS="${3:-30}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DUR=$(node -e "import('./src/shots.js').then(m=>console.log(m.DURATION))" 2>/dev/null || grep -oE "DURATION = [0-9.]+" src/shots.js | grep -oE "[0-9.]+")
mkdir -p chunks; rm -f chunks/*.mp4
STEP=$(python3 -c "import math;print(math.ceil($DUR*$FPS/$WORKERS)/$FPS)")
pids=()
for ((w = 0; w < WORKERS; w++)); do
  from=$(python3 -c "print($w*$STEP)"); to=$(python3 -c "print(min($DUR, ($w+1)*$STEP))")
  python3 -c "import sys;sys.exit(0 if $from < $DUR else 1)" || continue
  node "$DIR/render.mjs" video "chunks/c$(printf %02d $w).mp4" "$FPS" "$from" "$to" > "chunks/log$w.txt" 2>&1 & pids+=($!)
done
for p in "${pids[@]}"; do wait "$p"; done
ls chunks/c??.mp4 | sed "s#^#file '$PWD/#; s#\$#'#" > chunks/list.txt
ffmpeg -v error -y -f concat -safe 0 -i chunks/list.txt -c copy "$OUT"
echo "done: $OUT"
