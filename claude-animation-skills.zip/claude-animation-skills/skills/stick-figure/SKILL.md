---
name: stick-figure
description: Makes a code-animated stick-figure explainer from a question or topic, either a short reel (9:16, 30 to 45 s) or a long-form YouTube video (16:9, 3 to 15 min). A bright cartoon world with thick outlines, stick people with big white heads and faces, constant camera motion, whip transitions, 1 to 2 word captions, a playful underscore and cartoon sound effects, all generated in code and timed to the voiceover word by word. Before building it asks the user four things: short or long, their YouTube channel name, their @handle and their channel photo, which it uses for a subscribe end card. Use when the user runs /stick-figure or asks for a stick-figure, stickman or cartoon "what if" explainer, a short or a long video.
---

# /stick-figure

```
┌──────────────────────┐
│   ☀      ☁           │  bright sky, sea, props drawn in code
│      ◯   ◯           │  stick people with big white heads, expressive faces
│     /|\ /|\          │
│     / \ / \  🛢       │
│     eye patch        │  1-2 word captions, lowercase, ~70% down
└──────────────────────┘
```

**Subscribe end card:** every video can finish with a 3.4 s card for the user's own YouTube channel (their photo, channel name and @handle, a subscribe button that gets clicked, a ringing bell, confetti). See "Ask first" and "Subscribe card" below.

A worked example comes with it: `engine/template` is a finished 37 s reel, "What if pirate eye patches had nothing to do with missing eyes?"

## Ask first (every time, before writing anything)
Ask these four things together in one message (tappable choices where the client has them, otherwise plain text), and wait for the answers. Don't start the script, the voice or any shots until you have them. Skip a question only if the user already answered it in their request.

1. **Short or long?** A short (9:16, 30 s to 3 min, for Shorts, Reels and TikTok) or a long video (16:9, 3 to 15 min, for YouTube).
2. **YouTube channel name**, shown on the subscribe card (for example "The Human Pattern").
3. **@handle** (for example `@sketchstoriesink`).
4. **Channel photo**: ask the user to attach their profile picture (a square PNG or JPG works best; it is cropped to a square and shown in a circle). If they have no photo yet or want no end card, say so and build without one.

If the user already saved a channel (`kit/channels/channels.json`), offer it as an option ("Use <name>?") instead of asking for the name, handle and photo again.

Then save the channel once and reuse it for every later video:
```bash
python3 "$ENGINE/tools/add_channel.py" "<channel name>" "<@handle>" /path/to/attached-photo.png   # prints CHANNEL=<key>
```
Remember the key: step 8b builds with it.

## Short or long?
Settle this from the answer to question 1. If the user answered "short" or "long", use that. If they skipped it, any mention of YouTube, a "full video", "long form", landscape, or a length over 1 minute means **long**.

| | short | long |
|---|---|---|
| `web/format.js` | `window.FORMAT = 'short'` | `window.FORMAT = 'long'` |
| Frame | 1080x1920 | 1920x1080 |
| Script | 110 to 120 words, 38 to 40 s | about 150 words a minute: 450 words for 3 min, 750 for 5, 1500 for 10 |
| Shots | 10 to 12, most 2 to 4 s | one every 3 to 6 s, plus a new setup whenever the idea changes (about 40 for 3 min, 100 for 8) |
| Captions | 1 to 2 words, ~70% down | up to 3 words, near the bottom (`H * .86`); they can be turned off by deleting the `drawCaption(out, tNew)` line in `main.js` |
| Safe area | Instagram: x 100 to 980, y 220 to 1500 | YouTube: keep faces and key props inside x 96 to 1824, y 54 to 930 (above the captions) |

Everything else (voice, word timings, SFX, `make.sh`) is the same for both. Details for long videos are in "Long form" below.

## First use
This skill's folder is the "Base directory" Claude Code shows when it loads it.
```bash
SKILL_DIR="<base directory of this skill>"
ENGINE="$SKILL_DIR/engine"
KIT=$(python3 -c 'import os,sys;print(os.path.realpath(os.path.join(sys.argv[1],"..","..","kit")))' "$SKILL_DIR")
[ -x "$KIT/.venv/bin/python" ] && [ -d "$KIT/models" ] || bash "$KIT/setup.sh" --voice   # ~1 GB of voice models, once
PY="$KIT/.venv/bin/python"; export NODE_PATH="$KIT/node_modules"
```
Needs ffmpeg, Node and Python 3.9+. To see the example: `cp -r "$ENGINE/template" ~/reels/pirate && bash "$ENGINE/make.sh" ~/reels/pirate`.

## How it fits together
A reel is one folder:
- `script.json`: the voiceover, one sentence per entry.
- `captions.json`: optional text swaps for captions (`{"twenty five": "25"}`).
- `web/shots.js`: the shot list. Each shot is `SHOTS.push({start, end, tr, draw(ctx, lt, t)})` in seconds of the voiceover; `lt` is time inside the shot, `tr` is the transition out (`'whip'` or `'cut'`).
- `web/lib.js` (easing, keyframes `kf`, shapes, text), `web/chars.js` (the stick rig `drawStick`, hats, faces, arm IK, the eye patch), `web/env.js` (sky, clouds, sea, ships, deck, barrels, cannon, lantern, below deck), `web/main.js` (whip blur, vignette, grain, captions). Add new props to `env.js` or a new `env2.js` (list it in `web/index.html`).
- `audio.py`: music and SFX, all synthesised in code and placed in voiceover seconds.

`make.sh` makes the voice, aligns every word (`audio/words_new.json`), mixes the sound, renders the shots in parallel and writes `<folder>/<folder name>.mp4`.

**Timing:** `audio/words_ref.json` is the voice the shots were timed against. When the voice changes but the words don't, `make.sh` warps the shots onto the new take, so a new recording needs no edits. If the script changes, delete `audio/words_ref.json` (the next take becomes the reference) and re-time `shots.js`.

## Steps
0. **Format.** Set `web/format.js` to `'short'` or `'long'` (see above). The engine reads it everywhere: canvas size, caption size and position, whip distance, vignette.
1. **Script.** For a short: about 110 to 120 words for 38 to 40 seconds, one idea per sentence: a "what if" hook, the common belief, a turn on "But", examples that build, one shot that shows the mechanism, and a payoff that answers the hook. Show it to the user before animating.
2. **Facts.** Check every claim with sources. Hedge theories ("scientists think").
3. **Folder.** `cp -r "$ENGINE/template" <reel>`, then empty its `audio/` and replace `script.json` (and `captions.json`).
4. **Voice.** In the folder: `"$PY" "$ENGINE/tools/tts_kokoro.py"` (free) or the user's own recording, or ElevenLabs with `ELEVENLABS_API_KEY` (`"$PY" "$ENGINE/tools/tts_elevenlabs.py" audio/vo_el.mp3`). Put the take at `audio/vo.wav`, then `"$PY" "$ENGINE/tools/align.py" audio/vo.wav` and read the word times in `audio/words_new.json`.
5. **Shots.** Rewrite `web/shots.js`: for a short, about 10 to 12 setups, most 2 to 4 s, the explainer shot longer. A new idea gets a new setup. Start the hook in action on frame 1. In a short, keep faces and key props out of the caption band (y about 1250 to 1420) and inside Instagram's safe area (x 100 to 980, y 220 to 1500). In a long video, keep them above the caption band (y about 930 to 1020) and inside x 96 to 1824. The example shots are composed for 1080x1920 (they place things around x 540), so for a long video write new shots in 1920x1080 coordinates: use `W` and `H` rather than the numbers 1080 and 1920, and use the example only for how a shot is built.
6. **Stills.** From the folder: `node "$ENGINE/tools/render.js" stills 1.5,4.2,9.0` writes `stills/`. Look at the busiest moments and fix them before a full render. `node "$ENGINE/tools/render.js" stills shots` writes one still from the middle of every shot, which is the quickest way to review a long video (look at them in batches of about 12).
7. **Sound.** Edit the cues in `audio.py` against the word times. For a long video, don't hand-place every cue: write `chapters.json` (see "Long form") for the music and add SFX only on the moments that matter.
8. **Build.** `bash "$ENGINE/make.sh" <reel>` (keeps `audio/vo.wav`; pass `kokoro`, `elevenlabs` or a file to replace it). `WORKERS=8` on a machine with more cores. `AUDIO_ONLY=1` remixes the sound without re-rendering.
8b. **Channel.** Build with the channel you saved in "Ask first": `CHANNEL=<key> bash "$ENGINE/make.sh" <reel>`. To skip saving, pass it on the spot: `CHANNEL_NAME="My Channel" CHANNEL_HANDLE=@me CHANNEL_PHOTO=/path/photo.png bash "$ENGINE/make.sh" <reel>`. Leave `CHANNEL` unset, or use `CHANNEL=none`, for no end card. Before the final build, look at the card still (`render.js stills` at the last second) and check the name fits and the photo is not cut off.
9. **Hand over** `<reel>/<name>.mp4`.

## Subscribe card
- Channels, avatars and handles come from `kit/channels/` (`tools/add_channel.py` adds one from a photo; the same list is shared with `zach-d-films`). Optional `color` (card background, default `#3b3f52`) and `accent` (bell, confetti, default `#ffd23a`) fields can be added per channel in `channels.json`.
- The figure on the card is one of the video's own characters, never a pirate (unless the video is about pirates). In `web/outro.js` it uses `window.OUTRO_WHO` (a character name such as `'woman'`) when the video's helpers define `vDraw`, otherwise `OUTRO_HERO` (colors and hat for `drawStick`); set whichever matches the cast of the video you are making. A long channel name shrinks to fit the card automatically.
- `make.sh` copies the chosen channel (with its avatar) into the reel (`subscribe.json`, `web/subscribe.js`). `web/outro.js` draws the card, `main.js` appends it as one extra shot after the last one (the last shot becomes a `'whip'`), and `audio.py` adds its sounds (whoosh, pop, click, chime) and a bright music tail. Nothing in `shots.js` or `script.json` changes, and the card adds 3.4 s to the video.
- Works in both formats (short 9:16 and long 16:9). No voiceover on the card; if the user wants it spoken, add a last sentence to `script.json` ("Subscribe to <name> for more.") and re-time the last shot.
- To change the card, edit `drawSubscribeCard` in `engine/template/web/outro.js` (length: `window.OUTRO_LEN`, and `OUTRO` in `audio.py`).
- Old reel folders: copy `outro.js` and `subscribe.js` into their `web/`, add the two script tags to `index.html` (before `shots.js`) and apply the `main.js` change, or just recreate the folder from the template.

## Long form
For YouTube-length videos (3 to 15 min). The engine, tools and `make.sh` are the same; what changes is the writing and the pacing.

1. **Script as chapters.** Hook (10 to 20 s, the question and why it's surprising), then 3 to 8 chapters, then a payoff that answers the hook and a one-line sign-off. Each chapter has one claim, 2 to 4 beats of evidence and a turn into the next one ("But here's the part nobody tells you."). Put the chapter plan in front of the user with the script before animating. Write `script.json` one sentence per entry, as for a short. Check facts chapter by chapter and hedge theories; long videos have more claims to get wrong.
2. **Voice.** Kokoro handles a long `script.json` line by line, so it works as is (about 1 min of compute per 5 min of speech). A recorded voiceover of any length works too; `align.py` transcribes it in 40 s windows. Keep `audio/words_ref.json` as the timing reference exactly as for a short.
3. **Pacing.** Change something every 3 to 6 s: a new setup, a camera move, a new prop or a cutaway. Vary shot types across a chapter (wide, close-up, prop detail, a diagram or a text card) so it doesn't feel like one scene on repeat. Use `'whip'` between chapters and between big ideas, and `'cut'` inside a run of beats, so a whip means something. Re-use a few locations and characters through the video so the world feels consistent, and give each chapter its own sky or palette shift.
4. **Chapter cards.** Open each chapter with a 2 to 3 s title shot (big text, a simple prop, a whip in) built with the helpers in `lib.js`. They make a long video easy to follow and give the user YouTube chapter timestamps: print them at the end (`MM:SS title`, starting `00:00`).
5. **Music.** Write `chapters.json` in the reel folder: `[{"start": 0, "end": 48, "mood": "sunny"}, ...]` in seconds of the finished video, with moods `sunny`, `bright`, `tense` or `sneak`. `audio.py` then lays an underscore across the whole video (ducked under the voice) instead of the example's hand-placed cues. Alternate the moods across chapters and end on `bright`. SFX: a whoosh under every `'whip'`, plus impacts, pops and chimes on the beats that need them.
6. **Render.** `WORKERS=8 bash "$ENGINE/make.sh" <reel>` renders every shot in parallel and joins them. Expect roughly 1 to 3 min of render per minute of video on 8 cores. If a shot fails, read `seg/log*.txt`, fix it and run `make.sh` again. It re-renders everything, so check the stills first. The output is 1920x1080, 30 fps, about -14 LUFS, which suits YouTube.
7. **Hand over** the mp4, the chapter timestamps, and (if asked) a title and description.

## Running on claude.ai (free plan, no Claude Code)
This whole pipeline runs for free, inside the Claude workspace you already have:
1. Add the plugin to Claude (the `animation-skills` folder from the GitHub repo, uploaded as a plugin) and run `/animation-skills:stick-figure` with your topic.
2. The voice is **Kokoro AI TTS**, a free open-source model that runs in the workspace (`tools/tts_kokoro.py`). No ElevenLabs key or paid voice is needed; try the voices `am_adam`, `am_michael`, `af_heart`.
3. Render in the workspace too (`make.sh`), not on your own computer. First use runs `kit/setup.sh --voice` once (about 1 GB of models). If a Chromium is preinstalled, point the renderer at it with `CHROME=/path/to/chromium`.
4. A render takes a while. Start it in the background (`setsid nohup bash "$ENGINE/make.sh" <reel> > build.log 2>&1 &`), then check `build.log` and the number of files in `seg/` every minute or two instead of waiting in one long command.
5. Download the finished `<reel>/<name>.mp4`. Keep uploads under about 30 MB by re-encoding with `ffmpeg -crf 27` if needed.

## Style
- Captions: Poppins Bold, white with a dark outline, 1 to 2 words (up to 3 in a long video), lowercase, no punctuation (`capText()` in `main.js` does it; digits and `%` stay). No em dashes anywhere on screen.
- Bright saturated palette, ink outlines (`#221c22`), soft contact shadows, slow push-ins with handheld drift, whip transitions with motion blur. An impact is a burst, a shake and a flash.
- SFX sit under the voice (gain about 0.38). The music is a quiet plucked underscore, ducked under the voice, never a loud loop at the start.
