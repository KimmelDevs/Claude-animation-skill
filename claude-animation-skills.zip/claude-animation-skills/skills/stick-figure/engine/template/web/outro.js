// ---------- subscribe end card ----------
// Active only when web/subscribe.js sets window.SUBSCRIBE = {name, handle, color, accent} (make.sh writes it from channels.json).
// main.js appends one extra shot after the last one, window.OUTRO_LEN seconds long, with a whip in.
window.OUTRO_LEN = 3.4;
const OUTRO_AV = new Image(); window.OUTRO_READY = Promise.resolve();
if (window.SUBSCRIBE && window.SUBSCRIBE.avatar) { window.OUTRO_READY = new Promise(r => { OUTRO_AV.onload = OUTRO_AV.onerror = r; }); OUTRO_AV.src = window.SUBSCRIBE.avatar; }
const OUTRO_HERO = { cols: PAL.yellow, hat: 'none' };
function drawSubscribeCard(ctx, lt, t, ch) {
  const col = ch.color || '#ff3b30', acc = ch.accent || '#ffd23a';
  // background: channel colour gradient + slow sunburst
  const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, col); g.addColorStop(1, '#1d1530'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  ctx.save(); ctx.translate(W / 2, H * .42); ctx.rotate(t * .12);
  for (let i = 0; i < 14; i++) { ctx.rotate(TAU / 14); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.max(W, H) * 1.2, -90); ctx.lineTo(Math.max(W, H) * 1.2, 90); ctx.closePath(); ctx.fillStyle = 'rgba(255,255,255,.06)'; ctx.fill(); }
  ctx.restore();
  const u = LONG ? 1.0 : 1.0;
  const cx = LONG ? W * .62 : W / 2, cy = LONG ? H * .40 : H * .30;
  // channel card pops in
  const k = backOut(clamp(lt / .45)); ctx.save(); ctx.translate(cx, cy); ctx.scale(k, k);
  const cw = LONG ? 760 : 840, chh = 250;
  rrect(ctx, -cw / 2, -chh / 2, cw, chh, 60); ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = 30; ctx.shadowOffsetY = 12; fillStroke(ctx, '#fffaf0', 10); ctx.shadowColor = 'transparent';
  if (ch.avatar && OUTRO_AV.naturalWidth) { ctx.save(); circle(ctx, -cw / 2 + 140, 0, 92); ctx.clip(); ctx.drawImage(OUTRO_AV, -cw / 2 + 48, -92, 184, 184); ctx.restore(); circle(ctx, -cw / 2 + 140, 0, 92); fillStroke(ctx, null, 10); }
  else { circle(ctx, -cw / 2 + 140, 0, 92); fillStroke(ctx, col, 10); text(ctx, (ch.name || '?').trim().charAt(0).toUpperCase(), -cw / 2 + 140, 6, 110, '#fff', INK, 0); }
  const nm = ch.name || 'Channel'; let fs = 70; ctx.save(); while (fs > 30) { ctx.font = '700 ' + fs + 'px Poppins'; if (ctx.measureText(nm).width <= cw - 330) break; fs -= 2; } ctx.restore();
  text(ctx, nm, -cw / 2 + 270, -26, fs, INK, INK, 0, 'Poppins', 700, 'left');
  text(ctx, ch.handle || '', -cw / 2 + 270, 52, 40, '#7a6f80', INK, 0, 'Poppins', 700, 'left');
  ctx.restore();
  // button: red subscribe -> click -> grey subscribed
  const by = cy + chh / 2 + (LONG ? 150 : 190), bw = 560, bh = 150;
  const bk = backOut(clamp((lt - .55) / .4)); const click = lt > 1.7;
  const press = kf(lt, [[1.62, 1], [1.72, .9], [1.85, 1.04], [2.0, 1]]);
  ctx.save(); ctx.translate(cx, by); ctx.scale(bk * press, bk * press);
  rrect(ctx, -bw / 2, -bh / 2, bw, bh, 75); ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 10; fillStroke(ctx, click ? '#e8e3ec' : '#ff2a2a', 10); ctx.shadowColor = 'transparent';
  text(ctx, click ? 'subscribed' : 'subscribe', 0, 4, click ? 58 : 66, click ? '#3a3340' : '#fff', INK, 0);
  ctx.restore();
  // bell rings after the click
  const bx = cx + bw / 2 + 110, rk = clamp((lt - 1.8) / .1), ring = Math.sin((lt - 1.8) * 26) * .5 * Math.exp(-(lt - 1.8) * 2.2) * rk;
  if (click) { ctx.save(); ctx.translate(bx, by - 8); ctx.rotate(ring); ctx.scale(backOut(clamp((lt - 1.75) / .25)) * 1.0, backOut(clamp((lt - 1.75) / .25)) * 1.0);
    ctx.beginPath(); ctx.moveTo(-46, 38); ctx.quadraticCurveTo(-46, -8, -30, -34); ctx.quadraticCurveTo(0, -66, 30, -34); ctx.quadraticCurveTo(46, -8, 46, 38); ctx.closePath(); fillStroke(ctx, acc, 8);
    circle(ctx, 0, 52, 14); fillStroke(ctx, acc, 8); circle(ctx, 0, -66, 9); fillStroke(ctx, acc, 6); ctx.restore(); }
  // cursor hand tapping the button
  const hp = kf(lt, [[.9, [cx + 330, by + 260]], [1.6, [cx + 70, by + 30]]], easeOut);
  if (lt > .9 && lt < 2.5) { const a = inv(.9, 1.1, lt) * (1 - inv(2.2, 2.5, lt)); ctx.save(); ctx.globalAlpha = a; ctx.translate(hp[0], hp[1]); ctx.rotate(-.35);
    path(ctx, [[0, 0], [0, 110], [28, 84], [50, 130], [72, 120], [50, 76], [88, 76]]); fillStroke(ctx, '#fff', 9); ctx.restore(); }
  // click burst
  if (lt > 1.7 && lt < 2.3) { const p = inv(1.7, 2.3, lt); ctx.save(); ctx.globalAlpha = 1 - p; for (let i = 0; i < 10; i++) { const a = i / 10 * TAU, r0 = 300 + p * 120; line(ctx, cx + Math.cos(a) * r0 * 1.1, by + Math.sin(a) * r0 * .35, cx + Math.cos(a) * (r0 + 50), by + Math.sin(a) * (r0 * .35 + 18), 10, '#fff'); } ctx.restore(); }
  // stick hero cheering
  const hs = LONG ? 560 : 560, hx = LONG ? W * .22 : W / 2 - 40, hy = LONG ? H * .93 : H * .90;
  const hop = Math.abs(Math.sin(lt * 5)) * 26 * (click ? 1 : .3);
  if (typeof vDraw === 'function') {
    ctx.save(); vShadow && vShadow(ctx, hx, 140); ctx.restore();
    vDraw(ctx, window.OUTRO_WHO || 'woman', { x: hx, y: hy - hop, s: 560, arms: click ? AR.wave(lt, 9) : AR.point, face: { eyes: click ? 'happy' : 'normal', mouth: 'grin', look: [.6, 0] }, shadow: false });
  } else drawStick(ctx, Object.assign({}, OUTRO_HERO, { x: hx, y: hy - hop, s: hs,
    arms: { L: [2.6 + Math.sin(lt * 9) * .25, .25], R: click ? [2.7 - Math.sin(lt * 9) * .25, .25] : { ik: [.32, -.62], bend: 1 } },
    legs: { L: [.1, 0], R: [.1, 0] }, face: { eyes: click ? 'happy' : 'normal', mouth: 'grin', browAng: .2 } }));
  // confetti
  if (click) { const R = rng(7); for (let i = 0; i < 34; i++) { const x0 = R() * W, v = 260 + R() * 420, ph = R() * 6; const p = lt - 1.7; const y = -60 + p * v + 30 * Math.sin(p * 4 + ph); const x = x0 + 40 * Math.sin(p * 3 + ph); ctx.save(); ctx.translate(x, y); ctx.rotate(p * 5 + ph); ctx.fillStyle = [acc, '#fff', '#ff6b6b', '#7fe0ff'][i % 4]; ctx.fillRect(-9, -5, 18, 10); ctx.restore(); } }
  // closing line
  const ta = clamp((lt - 2.3) / .3); if (ta > 0) { ctx.save(); ctx.globalAlpha = ta; text(ctx, 'new videos all the time', cx, LONG ? H * .80 : by + 150, 44, '#fff', '#111', 10); ctx.restore(); }
}
