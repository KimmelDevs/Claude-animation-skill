// 'short' = 9:16 1080x1920 (reels/shorts), 'long' = 16:9 1920x1080 (YouTube)
window.FORMAT = 'short';
