#!/usr/bin/env python3
"""Save a YouTube channel for the subscribe end card.

  python3 add_channel.py "Channel Name" "@handle" /path/to/profile-photo.png [key]

Crops the photo to a square, saves it as kit/channels/<key>.png and adds the channel to
kit/channels/channels.json. Then build a video with  CHANNEL=<key> bash make.sh <reel>.
Needs ffmpeg (already required by the skill).
"""
import json, os, re, subprocess, sys

if len(sys.argv) < 4:
    sys.exit(__doc__)
name, handle, photo = sys.argv[1].strip(), sys.argv[2].strip(), sys.argv[3]
if handle and not handle.startswith('@'):
    handle = '@' + handle
key = sys.argv[4] if len(sys.argv) > 4 else re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-') or 'channel'
if not os.path.isfile(photo):
    sys.exit('photo not found: %s' % photo)
kit = os.path.realpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', '..', 'kit'))
cdir = os.path.join(kit, 'channels'); os.makedirs(cdir, exist_ok=True)
png = key + '.png'
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', photo, '-vf', "crop='min(iw,ih)':'min(iw,ih)',scale=512:512", '-frames:v', '1', os.path.join(cdir, png)], check=True)
f = os.path.join(cdir, 'channels.json')
chs = json.load(open(f)) if os.path.isfile(f) else {}
chs[key] = {'name': name, 'handle': handle, 'avatar': png}
json.dump(chs, open(f, 'w'), indent=2)
print('saved channel "%s" (%s) as CHANNEL=%s' % (name, handle, key))
